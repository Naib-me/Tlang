class Tio {
    println(text) {
        console.log(text)
    }
    print_str(text){
        process.stdout.write(text);
    }
}

tio = new Tio()
const a = 1