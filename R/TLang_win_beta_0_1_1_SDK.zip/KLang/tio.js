class Tio {
    println(text) {
        console.log(text)
    }
}

tio = new Tio()
